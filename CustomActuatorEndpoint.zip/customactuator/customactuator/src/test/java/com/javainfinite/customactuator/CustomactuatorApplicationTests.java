package com.javainfinite.customactuator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomactuatorApplicationTests {

	@Test
	void contextLoads() {
	}

}
